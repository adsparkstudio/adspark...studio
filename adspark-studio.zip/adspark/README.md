# AdSpark Studio
1. `npm install`
2. Copy `.env.example` to `.env`, add a Gmail App Password as SMTP_PASS (or another SMTP provider's details).
3. `npm start` → http://localhost:3000
The contact form only shows success when the server actually sends the email. Without credentials it shows an honest "not sent" message.
Opening the HTML files directly (no server) shows the site, but the form cannot send.
