// Static server + /api/contact. Needs SMTP credentials in .env (see README).
const http=require('http'),fs=require('fs'),path=require('path'),nodemailer=require('nodemailer');
try{fs.readFileSync('.env','utf8').split('\n').forEach(l=>{const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2]})}catch{}
const {SMTP_HOST,SMTP_PORT='587',SMTP_USER,SMTP_PASS,MAIL_TO='aleeza4ez@gmail.com',PORT=3000}=process.env;
const T={'.html':'text/html','.css':'text/css','.js':'text/javascript','.png':'image/png'};
const hits=new Map();
const send=(r,c,o)=>{r.writeHead(c,{'Content-Type':'application/json'});r.end(JSON.stringify(o))};
http.createServer((q,r)=>{
 if(q.method==='POST'&&q.url==='/api/contact'){
  const ip=q.socket.remoteAddress,n=(hits.get(ip)||[]).filter(t=>Date.now()-t<36e5);
  if(n.length>=5)return send(r,429,{error:'Too many messages. Please try again later.'});
  let b='';q.on('data',c=>{b+=c;if(b.length>2e4)q.destroy()});
  q.on('end',async()=>{let d;try{d=JSON.parse(b)}catch{return send(r,400,{error:'Invalid request.'})}
   if(d.website)return send(r,200,{ok:true}); // honeypot (bots)
   const s=k=>String(d[k]||'').trim().slice(0,3000);
   if(!s('name')||!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s('email'))||!s('service')||s('details').length<10)return send(r,400,{error:'Please complete all required fields.'});
   if(!SMTP_HOST||!SMTP_USER||!SMTP_PASS)return send(r,503,{error:'Email service is not configured on the server, so your message was not sent. Please email aleeza4ez@gmail.com or use WhatsApp.'});
   try{await nodemailer.createTransport({host:SMTP_HOST,port:+SMTP_PORT,secure:SMTP_PORT==='465',auth:{user:SMTP_USER,pass:SMTP_PASS}}).sendMail({
     from:SMTP_USER,to:MAIL_TO,replyTo:s('email'),subject:`AdSpark inquiry: ${s('service')} from ${s('name')}`,
     text:`Name: ${s('name')}\nEmail: ${s('email')}\nCompany: ${s('company')||'-'}\nService: ${s('service')}\n\n${s('details')}`});
    n.push(Date.now());hits.set(ip,n);send(r,200,{ok:true})}
   catch(e){console.error('Mail error:',e.message);send(r,502,{error:'The email could not be sent. Please try again or contact us directly.'})}});return}
 let p=decodeURIComponent(q.url.split('?')[0]);if(p==='/')p='/index.html';
 const f=path.join(__dirname,path.normalize(p));
 if(!f.startsWith(__dirname)||/server\.js|\.env|package/.test(p))return send(r,404,{});
 fs.readFile(f,(e,x)=>{if(e)return send(r,404,{error:'Not found'});r.writeHead(200,{'Content-Type':T[path.extname(f)]||'application/octet-stream'});r.end(x)})
}).listen(PORT,()=>console.log('AdSpark running on http://localhost:'+PORT));
